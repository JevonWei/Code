package gopkg

const VERSION = 2.5
