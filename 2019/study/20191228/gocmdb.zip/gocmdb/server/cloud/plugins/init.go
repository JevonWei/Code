package plugins

import (
	_ "github.com/imsilence/gocmdb/server/cloud/plugins/aliyun"
	_ "github.com/imsilence/gocmdb/server/cloud/plugins/tenant"
)
